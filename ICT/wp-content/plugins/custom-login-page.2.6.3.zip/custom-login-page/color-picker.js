// JavaScript Document

var args = {
	
	toggle: true
	
};

jQuery(document).ready(function(){
    jQuery('.color-picker').wpColorPicker(args);
});